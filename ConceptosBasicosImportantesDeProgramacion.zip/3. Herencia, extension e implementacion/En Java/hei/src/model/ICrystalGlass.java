package model;

public interface ICrystalGlass {
    static public String material() { return "Cristal"; }
}
