using System;

namespace model
{
    interface IVaso 
    {
        double getCapacity();
        double getWeight();
        string getMaterial();
        string getTypeOfGlass();
    }
}
