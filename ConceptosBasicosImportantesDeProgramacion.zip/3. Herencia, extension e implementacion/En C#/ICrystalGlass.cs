using System;

namespace model
{
    interface ICrystalGlass
    {
        public static string getMaterial() => "Cristal";
    }
}
